# Automatic_Subtitle_Generator
This application can generate subtitles automatically for any kind of videos.
